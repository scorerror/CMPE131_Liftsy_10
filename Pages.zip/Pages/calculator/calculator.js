'use strict';

angular.module('webApp.calculator', ['ngRoute', 'firebase'])

    .config(['$routeProvider', function($routeProvider) {
        $routeProvider.when('/calculator', {
            templateUrl: 'calculator/calculator.html',
            controller: 'calculatorCtrl'
        });
    }])

    .controller('calculatorCtrl', ['$scope', '$firebaseArray', '$location', 'CommonProp', function($scope, $firebaseArray, $location, CommonProp) {

        firebase.auth().onAuthStateChanged(function(user) {
            if (user) {
                $scope.username = CommonProp.getUser();
                var uid = user.uid;   

        if (!$scope.username) {
            $location.path('/home');
        }

        var ref = firebase.database().ref().child('Articles/' + uid);
        $scope.Articles = $firebaseArray(ref);

        $scope.createPost = function() {
            var title = $scope.calc.titleTxt;
            var calc = $scope.calc.postTxt;
            var post = $scope.calc.postTxt;
            $scope.Articles.$add({
                title: title,
                calc: calc,
                post: post

            }).then(function(ref) {
                console.log(ref);
                $scope.success = true;
                window.setTimeout(function() {
                    $scope.$apply(function() {
                        $scope.success = false;
                    });
                }, 2000);
            }, function(error) {
                console.log(error);
            });
        };
            } else {
                // No user is signed in.
            }
        });
        

    }]);

<!-- Author:  Steve Angelo -->


<!-- Date:  Sept. 16, 2002 -->

<!-- This script calculates RWL from drop down lists. -->

<!-- Sept. 23, 2002 (SA) Restrict manually input fields to value between 0 and 1. -->

<!--              -->




<!-- Begin
function checkmanualfld(field) {
    //Check range of manually input field
    //If invalid, alert user, clear field, and return focus to the field
    if ((field.value < 0) || (field.value > 1)) {
        alert('Field Value must be between 0 and 1');
        field.value = "";
        field.focus();
    }
}

function displayam() {
    document.form.am2.value = document.form.am.options[document.form.am.options.selectedIndex].value;
}

function displaydm() {
    document.form.dm2.value = document.form.dm.options[document.form.dm.options.selectedIndex].value;
}

function displayfm() {
    document.form.fm2.value = document.form.fm.options[document.form.fm.options.selectedIndex].value;
}

function displaycm() {
    document.form.cm2.value = document.form.cm.options[document.form.cm.options.selectedIndex].value;
}

function displayhm() {
    document.form.hm2.value = document.form.hm.options[document.form.hm.options.selectedIndex].value;
}

function displayvm() {
    document.form.vm2.value = document.form.vm.options[document.form.vm.options.selectedIndex].value;
}

function getRWL() {
    // ensure that proper values of fm, cm (selected by radio button) are
    // used in calculation 
    setfm();
    setcm();
    //set number of decimal places for calculation result
    var dec = 2;
    var am = document.form.am.options[document.form.am.options.selectedIndex].value;
    var dm = document.form.dm.options[document.form.dm.options.selectedIndex].value;
    var fm = document.form.fm.options[document.form.fm.options.selectedIndex].value;
    var cm = document.form.cm.options[document.form.cm.options.selectedIndex].value;
    var hm = document.form.hm.options[document.form.hm.options.selectedIndex].value;
    var vm = document.form.vm.options[document.form.vm.options.selectedIndex].value;

    var am3 = document.form.am3.value;
    var dm3 = document.form.dm3.value;
    var fm3 = document.form.fm3.value;
    var cm3 = document.form.cm3.value;
    var vm3 = document.form.vm3.value;
    var hm3 = document.form.hm3.value;

    document.form.am2.value = am;
    document.form.dm2.value = dm;
    document.form.fm2.value = fm;
    document.form.cm2.value = cm;
    document.form.vm2.value = vm;
    document.form.hm2.value = hm;

    //calculation from drop down list values selected
    document.form.rwl.value = round(23 * dm * vm * hm * fm * am * cm, 2);

    //calculation from manually entered values
    document.form.rwl2.value = round(23 * dm3 * vm3 * hm3 * fm3 * am3 * cm3, 2);

}


function round(number, X) {
    // rounds number to X decimal places, defaults to 2
    X = (!X ? 2 : X);
    return Math.round(number * Math.pow(10, X)) / Math.pow(10, X);
}


function setfm() {
    // change fm factor depending upon which radio button selected
    if ((document.form.fmfactor[1].checked) || (document.form.fmfactor[3].checked)) {
        document.form.fm.options[0].value = "0.85";
        document.form.fm.options[1].value = "0.75";
        document.form.fm.options[2].value = "0.65";
        document.form.fm.options[3].value = "0.45";
        document.form.fm.options[4].value = "0.27";
        document.form.fm.options[5].value = "0.13";
        document.form.fm.options[6].value = "0.00";
    } else {
        document.form.fm.options[0].value = "1.00";
        document.form.fm.options[1].value = "0.94";
        document.form.fm.options[2].value = "0.91";
        document.form.fm.options[3].value = "0.84";
        document.form.fm.options[4].value = "0.75";
        document.form.fm.options[5].value = "0.45";
        document.form.fm.options[6].value = "0.37";
    }


    if (document.form.fmfactor[3].checked) {
        document.form.fm.options[5].value = "0.00";
    }
    displayfm();
}


function setcm() {
    // change cm factor depending upon which radio button selected
    if (document.form.cmfactor[1].checked) {
        document.form.cm.options[1].value = "0.95";
    } else {
        document.form.cm.options[1].value = "1.00";
    }

    displaycm();
}