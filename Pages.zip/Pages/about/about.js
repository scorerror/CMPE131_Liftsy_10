'use strict';

angular.module('webApp.about', ['ngRoute', 'firebase'])

.config(['$routeProvider', function($routeProvider){
	$routeProvider.when('/about', {
		templateUrl: 'about/about.html',
		controller: 'aboutCtrl'
	});
}])
